import warnings

warnings.warn(
    'wtforms.ext.django is deprecated, and will be removed in WTForms 3.0. '
    'The package has been split out into its own package, wtforms-django: '
    'https://github.com/wtforms/wtforms-django',
    DeprecationWarning
)
