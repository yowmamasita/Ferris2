Changelog
---------

Here you can see the full list of changes between each WTForms-JSON release.


0.1.4 (2013-03-16)
^^^^^^^^^^^^^^^^^^

- Updated requirements



0.1.3 (2013-03-01)
^^^^^^^^^^^^^^^^^^

- Fixed 'First example' in docs
