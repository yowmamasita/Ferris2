wtforms-json
============

Adds smart json support for WTForms. Useful for when using WTForms with RESTful APIs.


Resources
---------

- `Documentation <http://wtforms-json.readthedocs.org/>`_
- `Issue Tracker <http://github.com/kvesteri/wtforms-json/issues>`_
- `Code <http://github.com/kvesteri/wtforms-json/>`_

